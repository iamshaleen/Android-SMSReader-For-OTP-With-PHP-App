package com.citi.va.sms_reader_vadummy_demo;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsProcessor {

    public static void processSMS(Context context, String message, String sender, String mobileNumber) {
        RequestQueue queue = Volley.newRequestQueue(context);
        String sowListUrl = "http://192.168.1.215:8888/POCMobileOTP/data" + mobileNumber + ".json";

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, sowListUrl, null, response -> {
            try {
                String sow = matchSOW(message, sender, mobileNumber,response);
                sendSMSData(queue, message, sow, sender, mobileNumber);
            } catch (Exception e) {
                Log.e("SmsProcessor", "Error processing SOW match: " + e.getMessage());
            }
        }, error -> Log.e("SmsProcessor", "Volley error fetching sowList: " + error.getMessage()));

        queue.add(request);
    }

    private static void sendSMSData(RequestQueue queue, String sms, String sow, String sender, String mobileNumber) {
        String url = "http://192.168.1.215:8888/POCMobileOTP/addSOW.php";
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                response -> Log.d("SmsProcessor", "Server response: " + response),
                error -> Log.e("SmsProcessor", "Volley POST error: " + error.getMessage())) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("sow", sow);
                params.put("mobile", mobileNumber);
                params.put("otpmessage", sms);
                params.put("sender", sender);
                return params;
            }
        };

        queue.add(postRequest);
    }

    private static String matchSOW(String sms, String sender, String mobileNumber,JSONArray sowList) {
        try {
            String defaultSOW ="";
            if(mobileNumber.equalsIgnoreCase("98765432")){
                defaultSOW = "1234567";
            }else{
                defaultSOW = "12345678";
            }

            if (sowList == null || sowList.length() == 0) return defaultSOW;
            ArrayList<String> sowMatches = new ArrayList<>();
            JSONArray tempArr = new JSONArray();

            for (int i = 0; i < sowList.length(); i++) {
                JSONObject obj = sowList.getJSONObject(i);
                if (obj.getString("sender").equalsIgnoreCase(sender)) {
                    tempArr.put(obj);
                }
            }

            if (tempArr.length() == 0) return defaultSOW;
            if (tempArr.length() == 1) {
                JSONObject item = tempArr.getJSONObject(0);
                String configMsg = item.optString("message", null);
                if (configMsg == null) return item.getString("sow_number");

                if (!startsWithNumber(configMsg)) {
                    if (sms.toLowerCase().startsWith(configMsg.toLowerCase())) {
                        return item.getString("sow_number");
                    } else {
                        return defaultSOW;
                    }
                } else {
                    if (!startsWithNumber(sms)) return defaultSOW;

                    int smsIdx = sms.indexOf(' ');
                    int msgIdx = configMsg.indexOf(' ');

                    if (smsIdx != -1 && msgIdx != -1 &&
                            sms.substring(smsIdx + 1).trim().toLowerCase()
                                    .startsWith(configMsg.substring(msgIdx + 1).trim().toLowerCase())) {
                        return item.getString("sow_number");
                    } else {
                        return defaultSOW;
                    }
                }
            } else {
                for (int i = 0; i < tempArr.length(); i++) {
                    JSONObject item = tempArr.getJSONObject(i);
                    String configMsg = item.optString("message", null);

                    if (configMsg == null) continue;

                    if (startsWithNumber(configMsg) && startsWithNumber(sms)) {
                        int smsIdx = sms.indexOf(' ');
                        int msgIdx = configMsg.indexOf(' ');

                        if (smsIdx != -1 && msgIdx != -1 &&
                                sms.substring(smsIdx + 1).trim().toLowerCase()
                                        .startsWith(configMsg.substring(msgIdx + 1).trim().toLowerCase())) {
                            sowMatches.add(item.getString("sow_number"));
                        }
                    } else if (sms.toLowerCase().startsWith(configMsg.toLowerCase())) {
                        sowMatches.add(item.getString("sow_number"));
                    }
                }

                if (sowMatches.size() == 1) return sowMatches.get(0);
                return defaultSOW;
            }
        } catch (Exception e) {
            Log.e("SmsProcessor", "SOW matching error: " + e.getMessage());
            if(mobileNumber.equalsIgnoreCase("98765432")){
                return "1234567";
            }else{
                return "12345678";
            }
        }
    }

    private static boolean startsWithNumber(String msg) {
        Pattern pattern = Pattern.compile("^\\d{4,8}");
        Matcher matcher = pattern.matcher(msg);
        return matcher.find();
    }
}
