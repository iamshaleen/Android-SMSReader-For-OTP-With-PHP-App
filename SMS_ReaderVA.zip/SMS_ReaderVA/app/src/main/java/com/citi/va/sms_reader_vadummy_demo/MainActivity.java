package com.citi.va.sms_reader_vadummy_demo;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private String lastSMS = "";

    private BroadcastReceiver smsUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String sender = intent.getStringExtra("sender");
            String message = intent.getStringExtra("message");
            String mobileNumber = intent.getStringExtra("mobileNumber");

            if (!message.equals(lastSMS)) {
                lastSMS = message;
                textView.setText("OTP Message: " + message + "\n\nSender: " + sender+"\n\nReceived On: "+mobileNumber);
            } else {
                Log.d("MainActivity", "Duplicate SMS, not processing again.");
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);

        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.READ_SMS,
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.INTERNET,
                Manifest.permission.READ_PHONE_STATE
        }, PackageManager.PERMISSION_GRANTED);

        readLatestSMS();
    }

    private void readLatestSMS() {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
            if (cursor != null && cursor.moveToFirst()) {
                String sender = cursor.getString(2).toLowerCase().trim();
                String message = cursor.getString(12).trim();
                lastSMS = message;
                textView.setText("OTP Message: " + message + "\n\nSender: " + sender);

            }
        } catch (Exception e) {
            Log.e("MainActivity", "Error reading latest SMS: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        LocalBroadcastManager.getInstance(this).registerReceiver(smsUpdateReceiver,
                new IntentFilter("NEW_SMS_RECEIVED"));
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(smsUpdateReceiver);
    }

    @Override
    protected void onResume() {
        super.onResume();
        readLatestSMS();
    }
}
