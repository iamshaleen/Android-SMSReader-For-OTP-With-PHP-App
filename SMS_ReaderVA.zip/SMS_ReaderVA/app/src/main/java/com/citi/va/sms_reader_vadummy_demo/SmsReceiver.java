package com.citi.va.sms_reader_vadummy_demo;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresPermission;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.util.Log;



public class SmsReceiver extends BroadcastReceiver {
    @RequiresPermission(Manifest.permission.READ_PHONE_STATE)

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        StringBuilder fullMessage = new StringBuilder();
        if (bundle != null) {
            Object[] pdus = (Object[]) bundle.get("pdus");
            String format = bundle.getString("format");

            if (pdus != null) {
                for (Object pdu : pdus) {
                    SmsMessage message = null;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        message = SmsMessage.createFromPdu((byte[]) pdu, format);
                    }

                    if (message != null) {
                        fullMessage.append(message.getMessageBody());

                    }


                    String messageBody = fullMessage.toString().trim();
                    String sender = message.getOriginatingAddress();
                    String mobileNumber = "";

                    // Android 5.1+ supports getting SIM info from the intent
                    int subscriptionId = bundle.getInt("subscription", -1); // or "subscriptionId"

                    if (subscriptionId != -1) {
                        SubscriptionManager sm = null;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                            sm = SubscriptionManager.from(context);
                        }
                        SubscriptionInfo info = null;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                            info = sm.getActiveSubscriptionInfo(subscriptionId);
                        }
                        if (info != null) {
                            int simSlotIndex = 0;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                                simSlotIndex = info.getSimSlotIndex();
                            }

                            Log.d("SMS", "Received SMS on SIM slot: " + simSlotIndex);
                            Log.d("SMS", "Sender is: " + sender);
                            Log.d("SMS", "Message is: " + messageBody);

                            if(simSlotIndex == 0){
                                mobileNumber = "98765432";

                            }else{
                                mobileNumber = "87654321";
                            }
                            SmsProcessor.processSMS(context, messageBody, sender, mobileNumber);
                            Intent localIntent = new Intent("NEW_SMS_RECEIVED");
                            localIntent.putExtra("sender", sender);
                            localIntent.putExtra("message", messageBody);
                            localIntent.putExtra("mobileNumber", mobileNumber);
                            LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent);

                        }
                    }
                }
            }
        }
    }
}

