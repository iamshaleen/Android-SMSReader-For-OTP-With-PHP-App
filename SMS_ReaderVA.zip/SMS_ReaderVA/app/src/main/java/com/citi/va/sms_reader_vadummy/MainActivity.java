package com.citi.va.sms_reader_vadummy;

import static android.text.TextUtils.indexOf;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import com.android.volley.*;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import org.json.JSONArray;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    public String SMSString="";
    public JSONArray sowList;
    public RequestQueue requestQueue;
    private String sow="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        sowList = new JSONArray();
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.RECEIVE_SMS}, PackageManager.PERMISSION_GRANTED);
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED);
        requestQueue = Volley.newRequestQueue(this);
        AsyncTaskRunner1 asyncTaskRunner1 = new AsyncTaskRunner1();
        asyncTaskRunner1.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

    }

    public void checkSOWList(){

        //Log.d("checkSOWList","Inside checkSOWList");
        try{

            String url = "http://192.168.1.215:8888/POCMobileOTP/data98765432.json";
            //Create an error listener to handle errors appropriately.
            JsonArrayRequest MyStringRequest = new JsonArrayRequest(Request.Method.GET, url, null , response -> {

                try {
                    if(response.length()!=0){
                        Log.d("checksowlist","temp array is "+response.toString().trim()+" size is "+response.length());
                        if (response.toString().equals(sowList.toString())){
                            Log.d("checksowlist","both arrays are same");

                        }else {
                            sowList=response;
                            Log.d("checksowlist","sow list is "+sowList);
                        }
                    }else {
                        Log.d("checksowlist", "array is empty");
                        sowList = null;
                    }

                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

            }, error -> {
                //This code is executed if there is an error.
                Log.e("checkSOWList","Volley error "+ error.getMessage() + " "+ error.networkResponse);

            });
            requestQueue.add(MyStringRequest);


        }catch(Exception e){
            Log.e("checkSOWList","Error catching "+ e.getMessage().trim());

        }
    }

    @SuppressLint("SetTextI18n")
    public void readSMS() {

        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                Log.d("readSMSaddr", "sender is " + cursor.getString(2).toLowerCase().trim());

                ArrayList sowArr = new ArrayList<>();

                if (!(this.SMSString.equals(cursor.getString(12).trim()))) {

                    Log.d("readSMS", "Message is not the same");
                    textView.setText("OTP Message: "+cursor.getString(12).trim()+"\r\n\r\nSender: "+cursor.getString(2));

                    if (sowList.length() == 0) {
                        Log.d("readSMS", "SOWList is null. Assigning default sow number");
                        sow = "12345678";
                    } else {
                        int count = 0;
                        JSONArray tempArr = new JSONArray();
                        for (int i = 0; i < sowList.length(); i++) {
                            //Log.d("readSMS","jsonObj is "+);
                            if (sowList.getJSONObject(i).getString("sender").toLowerCase().equals(cursor.getString(2).toLowerCase().trim())) {
                                count++;
                                tempArr.put(sowList.getJSONObject(i));
                            }
                        }
                        Log.d("readSMS", "count is " + count);
                        if (count == 0) {
                            Log.d("readSMS", "SOWList is not null. No Matching sow. Assigning default sow number");
                            sow = "12345678";
                        } else if (count == 1) {
                            if (tempArr.getJSONObject(0).getString("message").trim().equals(null)) {
                                Log.d("readSMS", "SOWList is not null. One match found and sow number assigned. Message is null");
                                sow = tempArr.getJSONObject(0).getString("sow_number");
                            } else if (!tempArr.getJSONObject(0).getString("message").trim().equals(null) && !startsWithNumber(tempArr.getJSONObject(0).getString("message").trim())) {
                                Log.d("readSMS","config message doesn't start with number");
                                if (cursor.getString(12).trim().toLowerCase().substring(0, (Math.min(cursor.getString(12).trim().toLowerCase().length(), tempArr.getJSONObject(0).getString("message").trim().length()))).equals(tempArr.getJSONObject(0).getString("message").trim().toLowerCase())) {
                                    sow = tempArr.getJSONObject(0).getString("sow_number");
                                    Log.d("readSMS", "SOWList is not null. One match found and sow number assigned. Message is not null and matched");
                                } else {
                                    sow = "12345678";
                                    Log.d("readSMS", "SOWList is not null. One match found and sow number assigned is default sow number. Message is not null but not matched");

                                }
                            } else if (!tempArr.getJSONObject(0).getString("message").trim().equals(null) && startsWithNumber(tempArr.getJSONObject(0).getString("message").trim())) {
                                Log.d("readSMS","config message starts with number");
                                if(!startsWithNumber(cursor.getString(12).trim().toLowerCase())){
                                    Log.d("readSMS","message doesn't start with number");
                                    sow = "12345678";
                                    Log.d("readSMS", "SOWList is not null. One match found and sow number assigned is default sow number. Message is not null but not matched");

                                }else{
                                    Log.d("readSMS","config message and otp message starts with number");
                                    int sms_space_after_number_index = cursor.getString(12).trim().toLowerCase().indexOf(' ');
                                    int message_space_after_number_index = tempArr.getJSONObject(0).getString("message").trim().indexOf(' ');

                                    if (cursor.getString(12).trim().toLowerCase().substring(sms_space_after_number_index+1, (Math.min(cursor.getString(12).trim().toLowerCase().length(), tempArr.getJSONObject(0).getString("message").trim().length()))).equals(tempArr.getJSONObject(0).getString("message").substring(message_space_after_number_index+1).trim().toLowerCase())) {
                                        sow = tempArr.getJSONObject(0).getString("sow_number");
                                        Log.d("readSMS", "SOWList is not null. One match found and sow number assigned. Message is not null and matched");
                                    } else {
                                        sow = "12345678";
                                        Log.d("readSMS", "SOWList is not null. One match found and sow number assigned is default sow number. Message is not null but not matched");

                                    }

                                }

                            }

                        } else {
                            Log.d("readSMS", "Inside Else when count >1");
                            for (int i = 0; i < count; i++) {
                                int x = cursor.getString(12).trim().toLowerCase().length() <= tempArr.getJSONObject(i).getString("message").length() ? 1 : 2;
                                Log.d("readSMS", "Inside Else for. Count is " + x);
                                Log.d("readSMS","config sms is "+tempArr.getJSONObject(i).getString("message").trim());
                                if(startsWithNumber(tempArr.getJSONObject(i).getString("message").trim())){
                                    Log.d("readSMS","config message starts with number");
                                    if(startsWithNumber(cursor.getString(12).trim().toLowerCase())){
                                        Log.d("readSMS","otp message also starts with number");
                                        int sms_space_after_number_index = cursor.getString(12).trim().toLowerCase().indexOf(' ');
                                        int message_space_after_number_index = tempArr.getJSONObject(i).getString("message").trim().indexOf(' ');
                                        Log.d("readSMS","cursor string is "+cursor.getString(12).trim().toLowerCase().substring(sms_space_after_number_index+1, (Math.min(cursor.getString(12).trim().toLowerCase().length(), tempArr.getJSONObject(i).getString("message").trim().length()))));
                                        Log.d("readSMS","config sms string is "+tempArr.getJSONObject(i).getString("message").substring(message_space_after_number_index+1).trim().toLowerCase());
                                        if (cursor.getString(12).trim().toLowerCase().substring(sms_space_after_number_index+1, (Math.min(cursor.getString(12).trim().toLowerCase().length(), tempArr.getJSONObject(i).getString("message").trim().length()))).equals(tempArr.getJSONObject(i).getString("message").substring(message_space_after_number_index+1).trim().toLowerCase())) {
                                            sowArr.add(tempArr.getJSONObject(i).getString("sow_number"));
                                        }
                                    }


                                }else{
                                    Log.d("readSMS","config message doesn't start with number");
                                    if (cursor.getString(12).trim().toLowerCase().substring(0, (Math.min(cursor.getString(12).trim().toLowerCase().length(), tempArr.getJSONObject(i).getString("message").trim().length()))).equals(tempArr.getJSONObject(i).getString("message").trim().toLowerCase())) {
                                        sowArr.add(tempArr.getJSONObject(i).getString("sow_number"));
                                    }

                                }
                            }
                            if (sowArr.size() == 1) {
                                Log.d("readSMS", "Custom sow arr size is " + sowArr.size() + " inside if entry is" + sowArr);
                                sow = sowArr.get(0).toString();
                                Log.d("readSMS", "Only one match. Sow is " + sow);
                            } else {
                                Log.d("readSMS", "Custom sow arr size is " + sowArr.size() + " inside else entry is" + sowArr);
                                Log.d("readSMS", "More than one match. Sow is " + sow);
                                sow = "12345678"; //change this code pending by Shaleen in later update
                            }
                            sowArr = null;
                        }
                        tempArr = null;

                    }

                    setSMSString(cursor.getString(12).trim());
                    sendSMSData(this.SMSString, sow, cursor.getString(2).toLowerCase().trim());

                }

            }else{
                Log.d("readSMS", "Cursor is null. There are no messages");
            }
        } catch (Exception e) {

            //Log.d("readSMS", "Inside Catch");
            Log.e("readSMS", e.getMessage().trim());
            //readSMS();
        } finally {
            if (cursor!=null){
                cursor.close();
                cursor = null;
            }
        }

    }

    public void sendSMSData(final String str, final String sow, final String sender){
        //Log.d("sendSMSData","Inside sendSMSData");
        try{

            String url = "http://192.168.1.215:8888/POCMobileOTP/addSOW.php";
            //Create an error listener to handle errors appropriately.
            StringRequest MyStringRequest = new StringRequest(Request.Method.POST, url, response -> {
                Log.d("sendSMSData", response.trim());
                //This code is executed if the server responds, whether or not the response contains data.
                //The String 'response' contains the server's response.
            }, error -> {
                //This code is executed if there is an error.
                Log.d("sendSMSData","Volley error "+ error.getMessage());

            }) {
                protected Map<String, String> getParams() {
                    Map<String, String> MyData = new HashMap<>();
                    MyData.put("sow", sow);
                    MyData.put("mobile","98765432");
                    MyData.put("otpmessage", str);//Add the data you'd like to send to the server.
                    MyData.put("sender", sender);
                    return MyData;
                }
            };

            requestQueue.add(MyStringRequest);

        }catch (Exception e){
            //Log.d("sendSMS", "Inside Catch");
            Log.e("sendSMS", e.getMessage().trim());
        }

    }

    public void setSMSString(String str){

        this.SMSString = str;
    }

    private boolean startsWithNumber(String message) {
        Pattern pattern = Pattern.compile("^\\d{4,8}"); // Regex to match 8 digits at the start
        Matcher matcher = pattern.matcher(message);
        return matcher.find();
    }

    @SuppressLint("StaticFieldLeak")
    private class AsyncTaskRunner1 extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] objects) {
            //Log.d("Inside task1","inside task1");
            while(true){
                //Log.d("Async1","Inside Async1");
                checkSOWList();
                readSMS();
                try {
                    Thread.sleep(1000); // Add a delay of 1 seconds (adjust as needed)
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    @Override
    protected void onDestroy() {
        if (requestQueue != null) {
            requestQueue.stop();
        }
        super.onDestroy();
    }

}